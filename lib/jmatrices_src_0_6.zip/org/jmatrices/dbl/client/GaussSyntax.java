package org.jmatrices.dbl.client;

/**
 * GaussSyntax  todo
 * <p>Author: purangp</p>
 * Date: 30.04.2004
 * Time: 14:52:28
 */
public class GaussSyntax {
}
